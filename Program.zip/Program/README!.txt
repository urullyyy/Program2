Open Setup as an Administrator and after u did that open "ProgramName" to install the "ProgramName"

Open "Setup" as an Admin
And Open ""ProgramName" not as Admin